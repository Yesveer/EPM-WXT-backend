#!/bin/bash
set -e

echo "Installing vsay-agent..."

# Install binary
sudo cp vsay-agent /usr/local/bin/
sudo chmod +x /usr/local/bin/vsay-agent

# Create directories
sudo mkdir -p /etc/vsay
sudo mkdir -p /var/log/vsay
sudo chmod 755 /etc/vsay
sudo chmod 755 /var/log/vsay

# Install systemd service
sudo cp vsay-agent.service /etc/systemd/system/
sudo systemctl daemon-reload

echo "✓ Installation complete!"
echo ""
echo "Next steps:"
echo "1. Configure: sudo vsay-agent configure --token <token> --tenant <tenant> --org <org> --project <project> --user <email> --linux-user <username> --host <host> --allow-sudo"
echo "2. Start: sudo systemctl start vsay-agent"
